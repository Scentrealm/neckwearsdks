from crcmod import crcmod
from binascii import unhexlify

class NeckWear:
    def __init__(self):
        self.Frame_Head = 'F5'
        self.Frame_Tail = '55'

        self.PLAY_CMD = '12 01 00 {} 02 05'

        self.STOP_CMD = '12 00 00 01 00 01 00'

        # 地址
        self.address = 0

    def crc16Add(self, str_data):
        crc16 = crcmod.mkCrcFun(0x18005, rev=True, initCrc=0xFFFF, xorOut=0x0000)
        data = str_data.replace(" ", "")
        readcrcout = hex(crc16(unhexlify(data))).upper()
        str_list = list(readcrcout)
        if len(str_list) < 6:
            str_list.insert(2, '0'*(6-len(str_list)))  # 位数不足补0
        crc_data = "".join(str_list)
        return crc_data[2:4]+' '+crc_data[4:]

    def ten2sixteen(self, num, length):
        """
        十进制转十六进制
        :param num: 十进制数字
        :param length: 字节长度
        :return:
        """
        data = str(hex(eval(str(num))))[2:]
        data_len = len(data)
        if data_len % 2 == 1:
            data = '0' + data
            data_len += 1

        sixteen_str = "00 " * (length - data_len//2) + data[0:2] + ' ' + data[2:]
        return sixteen_str.strip()

    def playSmell(self, scentid, playtime):
        """
        十进制转十六进制
        :param scentid: 通道号
        :param playtime: 播放时长
        :return:
        self.pserial.write(bytes.fromhex(cmd))
        """
        straddress = self.ten2sixteen(self.address, 1)
        scent_channel = self.ten2sixteen(scentid, 1)
        play_time = self.ten2sixteen(playtime, 4)
        str_data = self.PLAY_CMD.format(straddress) + ' ' + scent_channel + ' ' + play_time
        verify = self.crc16Add(str_data)
        cmd = self.Frame_Head + ' ' + str_data + ' ' + verify + ' ' + self.Frame_Tail
        # print(cmd)
        return cmd;

    def getUuid(self):

        return "";

    def wakeUp(self):

        return "";

    def stopPlay(self):
        stop_cmd = '12 00 00 01 00 01 00'
        verify = self.crc16Add(stop_cmd)
        cmd = self.Frame_Head + ' ' + stop_cmd + ' ' + verify + ' ' + self.Frame_Tail
        return cmd;

    def setChl(self, chl):

        return "" ;

