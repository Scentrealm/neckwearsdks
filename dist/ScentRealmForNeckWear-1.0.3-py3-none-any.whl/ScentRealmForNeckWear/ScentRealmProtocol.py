from crcmod import crcmod
from binascii import unhexlify
import binascii

class NeckWear:
    def __init__(self):
        # 包头
        self.Frame_Head = 'F5'
        # 包尾
        self.Frame_Tail = '55'
        # 播放指令
        self.PLAY_CMD = '01 00 01 02 FF FF 01 00 00 00'
        # 指定设备播放指令
        self.PLAY_CMD_DEV = '01 00 01 02'
        # 停止指令
        self.STOP_CMD = '01 00 01 02 FF FF 02'
        # 获取物理信道
        # self.PhysicalChl = 'F5 27 00 27 55'
        # 获取UUID固定指令
        self.GETUUID_CMD = 'F5 27 00 27 55'
        # 设置UID指令
        self.SETUUID_CMD = '01 00 00 02 FF FF 22'
        # 唤醒固定指令
        self.WakeUp_CMD = 'F5 71 55'
        # 地址
        self.address = 0
        # 信道
        self.Channel = 0

    def setAttr_Channel(self, chlnum):
        """
        :param chlnum: Set The Object Channel Attribute
        """
        self.Channel = chlnum
        return self.Channel

    def getAttr_Channel(self):
        """
        :return: Get The Object Channel Attribute
        """
        return self.Channel

    def crc16Add(self, str_data):
        """
        :param str_data: calculate crc cmd,string like '12 00 00 01 00 01 00'
        """
        crc16 = crcmod.mkCrcFun(0x18005, rev=True, initCrc=0xFFFF, xorOut=0x0000)
        data = str_data.replace(" ", "")
        readcrcout = hex(crc16(unhexlify(data))).upper()
        str_list = list(readcrcout)
        if len(str_list) < 6:
            str_list.insert(2, '0' * (6 - len(str_list)))  # 位数不足补0
        crc_data = "".join(str_list)
        return crc_data[2:4] + ' ' + crc_data[4:]

    def checkSum(self, str_data):
        """
        :param str_data: calculate sum cmd,string like '12 00 00 01 00 01 00'
        """
        s = 0
        if len(str_data) < 1:
            return 0
        s = (sum([int(i, 16) for i in str.split(str_data, ' ') if i != '']))
        s = s & 0xffff
        return s

    def ten2sixteen(self, num, length):
        """
        十进制转十六进制
        :param num: 十进制数字
        :param length: 字节长度
        :return:
        """
        data = str(hex(eval(str(num))))[2:]
        data_len = len(data)
        if data_len % 2 == 1:
            data = '0' + data
            data_len += 1

        sixteen_str = "00 " * (length - data_len // 2) + data[0:2] + ' ' + data[2:]
        return sixteen_str.strip().upper()

    def playSmell(self, scentid, playtime):
        """
        Play Smell
        :param scentid: 通道号
        :param playtime: 播放时长
        :return:
        self.pserial.write(bytes.fromhex(cmd))
        """
        scent_channel = self.ten2sixteen(scentid, 1)
        play_time = self.ten2sixteen(playtime * 1000, 4)
        # print(play_time)
        str_data = self.PLAY_CMD + ' ' + scent_channel + ' ' + play_time
        verify = self.checkSum(str_data)
        cmd = self.Frame_Head + ' ' + str_data + ' ' + self.ten2sixteen(verify, 2) + ' ' + self.Frame_Tail
        # print(cmd)
        cmd = self.cmdPackage(cmd)
        # print(cmd)
        return cmd

    def playSmellForDevice(self, scentid, playtime, devid):
        """
        Play Smell
        :param scentid: 通道号
        :param playtime: 播放时长
        :return:
        self.pserial.write(bytes.fromhex(cmd))
        """
        scent_channel = self.ten2sixteen(scentid, 1)
        play_time = self.ten2sixteen(playtime * 1000, 4)
        device_id = self.ten2sixteen(devid, 2);

        # 01 00 01 02 FF FF 01 00 00 00
        # 01 00 01 02
        str_data = self.PLAY_CMD_DEV + ' ' + device_id + ' 01 00 00 00 ' + scent_channel + ' ' + play_time
        verify = self.checkSum(str_data)
        cmd = self.Frame_Head + ' ' + str_data + ' ' + self.ten2sixteen(verify, 2) + ' ' + self.Frame_Tail
        # print(cmd)
        cmd = self.cmdPackage(cmd)
        # print(cmd)
        return cmd

    def getUuid(self):
        """
        获取遥控器的UUID
        :return:
        """
        cmd = self.GETUUID_CMD
        # cmd = self.cmdPackage(cmd)
        return cmd

    def wakeUp(self):
        """
        脖戴设备唤醒指令
        :return:
        """
        cmd = self.cmdPackage(self.WakeUp_CMD)
        return cmd

    def stopPlay(self):
        stop_cmd = '01 00 01 02 FF FF 02'
        verify = self.checkSum(stop_cmd)
        cmd = self.Frame_Head + ' ' + stop_cmd + ' ' + self.ten2sixteen(verify, 2) + ' ' + self.Frame_Tail
        cmd = self.cmdPackage(cmd)
        return cmd

    def setNeckWearChl(self, chlnum, uidstr):
        """
        SET NeckWear Physical Channel
        :param chlnum: Physical Channel,Range: 1~255
        :param uidstr: UID: 56ff6a067875535658261267 -> 56 FF 6A 06 78 75 53 56 58 26 12 67
        :return:
        """
        str_data = self.SETUUID_CMD + ' ' + uidstr + ' ' + self.ten2sixteen(chlnum, 1)
        verify = self.checkSum(str_data)
        cmd = self.Frame_Head + ' ' + str_data + ' ' + self.ten2sixteen(verify, 2) + ' ' + self.Frame_Tail
        cmd = self.cmdPackage(cmd)
        return cmd

    def setHandset(self, macchl):
        str_data = '26 ' + self.ten2sixteen(macchl, 1)
        verify = self.checkSum(str_data)
        cmd = self.Frame_Head + ' ' + str_data + ' ' + self.ten2sixteen(verify, 2) + ' ' + self.Frame_Tail
        return cmd

    # 透传指令包装，指令编号51
    def cmdPackage(self, cmdstr):
        cmdtmp = cmdstr.replace(" ", "")
        cmdlen = 0
        data_len = len(cmdtmp)
        if data_len % 2 == 1:
            data_len += 1
        cmdlen = int(data_len / 2)
        cmdstr1 = '51 ' + self.ten2sixteen(self.Channel, 1) + ' ' + self.ten2sixteen(cmdlen, 1) + ' ' + cmdstr

        s = self.checkSum(cmdstr1)
        cmd = self.Frame_Head + ' 51 ' + self.ten2sixteen(self.Channel, 1) + ' ' + self.ten2sixteen(cmdlen,
                                                                                                    1) + ' ' + cmdstr + ' ' + self.ten2sixteen(
            s, 2) + ' ' + self.Frame_Tail
        return cmd

    def cmdParse(self, cmdstr):
        """
        Protocol Parse NeckWear Data
        :param cmdstr: Data String Like 'F5 A7 96 01 3D 55'
        :return: CmdCode, ContentString
        """
        cmd = 0
        datastr = ''
        dataint = 0
        # F5 A7 96 01 3D 55 获取物理信道
        # F5 A6 00 00 A6 55 设置返回的物理信道
        # F5 D1 00 18 F5 01 00 01 02 00 00 A2 56 FF 6A 06 78 75 53 56 58 26 12 67 00 04 F8 55 08 27 55 设置脖戴的物理信道
        cmdList = cmdstr.split()
        if len(cmdList) > 5:
            strcmd = cmdList[1]
            cmd = int(strcmd, 16)
            if strcmd == 'A7':
                datastr = cmdList[2]
            elif strcmd == 'A6':
                datastr = cmdList[2]
            elif strcmd == 'D1':
                datalen = int(cmdList[3], 16)
                datalen = 4 + datalen
                sub_list = cmdList[4:datalen]
                datastr = ' '.join(sub_list)
            else:
                datastr = ""
        return cmd, datastr

    def pack_data(self, cmd_str):
        """
        Data String To Bytes
        :param cmd_str: Data String Like 'F5 A7 96 01 3D 55'
        :return:
        """
        cmd = cmd_str
        hexstr = cmd.replace(' ', '')
        v4 = binascii.a2b_hex(hexstr)
        return v4
